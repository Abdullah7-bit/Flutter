package com.example.abdullah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
